## firmware/distfiles.mk
##
##    AudioScience HPI driver
##    Copyright (C) 1997-2017  AudioScience Inc. <support@audioscience.com>
##
##    This program is free software; you can redistribute it and/or modify
##    it under the terms of version 2 of the GNU General Public License as
##    published by the Free Software Foundation;
##
##    This program is distributed in the hope that it will be useful,
##    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##    GNU General Public License for more details.
##
##    You should have received a copy of the GNU General Public License
##    along with this program; if not, write to the Free Software
##    Foundation, Inc., 59 Temple Place, Suite 330,
##    Boston, MA  02111-1307  USA
##

firmware-dsp-bins = dsp6205.bin dsp6200.bin dsp6400.bin dsp6600.bin dsp6780.bin \
	dsp6790.bin dsp8900.bin
firmware-gen-dist-files = hpi_version.mk distfiles.mk
firmware-src-dist-files = Makefile dspinfo.py firmwaredir.sh
firmware-all-dist-files = $(firmware-src-dist-files) $(firmware-dsp-bins) $(firmware-gen-dist-files)
