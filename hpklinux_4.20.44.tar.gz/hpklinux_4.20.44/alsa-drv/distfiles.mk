
# Include common firmware file lists
-include firmware/distfiles.mk

src-files = asihpi.c trace_asihpi.h \
	hpi6000.c hpi6000.h\
	hpi6205.c hpi6205.h\
	hpi6700.c hpi6700.h\
	hpidspcd.c hpidspcd.h \
	hpicheck.h \
	hpicmn.c hpicmn.h\
	hpidebug.c hpidebug.h\
	hpifunc.c hpi.h hpi_internal.h\
	hpimsginit.c hpimsginit.h\
	hpimsgx.c hpimsgx.h\
	hpioctl.c hpioctl.h\
	hpios.c hpios.h \
	hpi_version.h \
	hpipcida.h

local-firmware-dist-files = $(addprefix firmware/,$(firmware-all-dist-files))

installed-files = $(local-firmware-dist-files)

build-files = \
	Makefile \
	extra.mk \
	kmod_config.sh \
	hpi_version.mk \
	distfiles.mk \
	$(src-files)

src-dist-files = \
	INSTALL.asihpi-alsa \
	dkms.conf \
	dkms-postinstall.sh \
	$(build-files)

all-dist-files = $(src-dist-files) $(installed-files)
