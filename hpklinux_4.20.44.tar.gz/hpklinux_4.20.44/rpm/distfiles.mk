
src-dist-files = Makefile hpi_version.mk hpklinux.spec distfiles.mk
