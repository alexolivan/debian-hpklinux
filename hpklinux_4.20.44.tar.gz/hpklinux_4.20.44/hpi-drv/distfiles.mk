
# Include common firmware file lists
-include firmware/distfiles.mk

src-files = \
	hpi6000.c hpi6000.h\
	hpi6205.c hpi6205.h\
	hpi6700.c hpi6700.h\
	hpimod.c \
	hpidspcd.c hpidspcd.h \
	hpicheck.h \
	hpicmn.c hpicmn.h\
	hpidebug.c hpidebug.h\
	hpifunc.c hpi.h hpi_internal.h\
	hpimsginit.c hpimsginit.h\
	hpimsgx.c hpimsgx.h\
	hpioctl.c hpioctl.h\
	hpios.c hpios.h \
	hpi_version.h \
	hpipcida.h

local-firmware-dist-files = $(addprefix firmware/,$(firmware-all-dist-files))

installed-files = asihpi.rules $(local-firmware-dist-files)

build-files = \
	Makefile \
	extra.mk \
	kmod_config.sh \
	hpi_version.mk \
	distfiles.mk \
	$(src-files)

src-dist-files = \
	dkms.conf \
	dkms-postinstall.sh \
	$(src-files) \
	$(build-files)

all-dist-files = $(src-dist-files) $(installed-files)
