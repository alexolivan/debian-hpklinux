
installed-headers = \
	hpi.h hpirds.h hpi_version.h hpi_internal.h hpios.h hpifilestore.h \
	hpidebug.h hpiudp_cache.h hpicmn.h hpinet.h hpissx2.h hpicheck.h \
	hpidspcd.h hpifirmware.h hpimsginit.h
common-sources =\
	hpifunc.c\
	hpimsginit.h\
	hpi_error_text.c\
	hpimsginit.c\
	hpidebug.c \
	hpirds.c \
	hpi.h\
	hpi_internal.h\
	hpi_version.h\
	hpifilestore.h\
	hpirds.h\
	hpios.h\
	hpidebug.h\
	hpiudp_cache.h\
	hpicmn.h
all-sources = \
	hpiwrap.c \
	hpiudp.c \
	hpicmn.c \
	hpinet.h \
	hpifilestore.c \
	hpios.c \
	hpiudp_cache.c \
	hpimux.c \
	hpinet.h \
	hpissx2.c \
	hpissx2.h

extra-dist = hpicheck.h hpidspcd.h hpidspcd.c hpios.c hpifirmware.h Doxyfile
src-dist-files = Makefile hpi_version.mk distfiles.mk $(common-sources) $(all-sources) $(extra-dist)
