
src-dist-files = \
	audioscience/hpimeters.py \
	audioscience/hpi.py \
	audioscience/__init__.py \
	audioscience/scrolled.py \
	hpicontrol.py \
	hpiexplog.py \
	hpi_dicts.py \
	hpimixer.py \
	dab_data.py \
	dabtest.py \
	hpisave.py \
	setup.py

setup-files = $(src-dist-files) hpi_version.mk distfiles.mk Makefile
