
asihpitest-srcs = asihpitest.c
asihpirec-srcs = asihpirec.c
asihpiplay-srcs = asihpirec.c
asihpitune-srcs = asihpitune.c hpirds.c
asihpiassert-srcs = asihpiassert.c
asihpibl-srcs = asihpibl.c
asihpirds-srcs = asihpirds.c
asihpi-si4688-srcs = asihpi_si4688.c
asi-firmware-updater-srcs = firmdown.c hpifirmware.c hpifunc.c hpidspcd.c hpios.c
src-dist-files = Makefile hpi_version.mk distfiles.mk $(asihpitest-srcs) $(asihpirec-srcs) $(asihpiplay-srcs) \
	$(asihpitune-srcs) $(asihpiassert-srcs) $(asi-firmware-updater-srcs) \
	$(asihpibl-srcs) $(asihpirds-srcs) $(asihpi-si4688-srcs)
